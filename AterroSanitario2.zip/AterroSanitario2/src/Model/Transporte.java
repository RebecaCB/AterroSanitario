/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author samuel
 */
public class Transporte {
    private Long id;
    private String motorista;
    private String cpf;
    private String placa;
    private String empresa;
    private Long id_usuario;

 
    public Transporte(){
        
    }
    
    
    public Transporte (Long id, String motorista, String cpf, String placa, String empresa, Long id_usuario){
        this.id = id;
        this.motorista = motorista;
        this.cpf = cpf;
        this.placa = placa;
        this.empresa = empresa;
        this.id_usuario = id_usuario;
        
    }   
       public Transporte ( String motorista, String cpf, String placa, String empresa, Long id_usuario){
        this.motorista = motorista;
        this.cpf = cpf;
        this.placa = placa;
        this.empresa = empresa;
        this.id_usuario = id_usuario;
        
    }
    
    

    public Long getId() {
        return id;
    }

 
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getMotorista() {
        return motorista;
    }

  
    public void setMotorista(String motorista) {
        this.motorista = motorista;
    }

 
    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }


    public String getPlaca() {
        return placa;
    }

    
    public void setPlaca(String placa) {
        this.placa = placa;
    }

    
    public String getEmpresa() {
        return empresa;
    }

    
    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    /**
     * @return the id_usuario
     */
    public Long getId_usuario() {
        return id_usuario;
    }

    /**
     * @param id_usuario the id_usuario to set
     */
    public void setId_usuario(Long id_usuario) {
        this.id_usuario = id_usuario;
    }

   

}

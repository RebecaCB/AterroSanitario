/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.time.LocalDate;
import javafx.scene.chart.PieChart.Data;

/**
 *
 * @author samuel
 */
public class Passeios {
    private String instituicao;
    private String responsavel;
    private String finalidade;
    private LocalDate datavisita;


    public String getInstituicao() {
        return instituicao;
    }

 
    public void setInstituicao(String instituicao) {
        this.instituicao = instituicao;
    }


    public String getResponsavel() {
        return responsavel;
    }


    public void setResponsavel(String responsavel) {
        this.responsavel = responsavel;
    }


    public String getFinalidade() {
        return finalidade;
    }


    public void setFinalidade(String finalidade) {
        this.finalidade = finalidade;
    }


    public LocalDate getDatavisita() {
        return datavisita;
    }

  
    public void setDatavisita(LocalDate datavisita) {
        this.datavisita = datavisita;
    }
}

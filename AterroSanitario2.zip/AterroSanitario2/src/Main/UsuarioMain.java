/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import Model.Usuario;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import Controller.UsuarioController;

/**
 *
 * @author Aluno
 */
public class UsuarioMain extends Application {
    private static Stage stage;
    
    public UsuarioMain(){
    
    }
    
    public UsuarioMain(Usuario s){
     UsuarioController.setUser(s);
    }
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/View/Usuario.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.setTitle("Tela de Login");
        stage.show();
        UsuarioMain.stage = stage;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    public static Stage getStage(){
        return UsuarioMain.stage;
    }
    public void setStage(Stage s){
        UsuarioMain.stage = s;
    }
}

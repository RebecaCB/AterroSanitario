/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.PasseiosDAO;
import Main.AgendarPasseiosMain;
import Main.PrincipalMain;
import Model.Passeios;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Aluno
 */
public class AgendarPasseiosController implements Initializable {

    @FXML
    private MenuItem btinspsanitaria;

    @FXML
    private Button btagendar;

    @FXML
    private TextField tfresponsavel;

    @FXML
    private DatePicker dpdata;

    @FXML
    private MenuButton btescolha;

    @FXML
    private MenuItem btpasseio;

    @FXML
    private AnchorPane ap;

    @FXML
    private Label lnr;

    @FXML
    private TextField tfinstituicao;

    @FXML
    private MenuItem btvistecnica;

    @FXML
    private Button btcancelar;

    @FXML
    private Label lfv;

    @FXML
    private Label ldv;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        dpdata.setShowWeekNumbers(true);

        btcancelar.setOnMouseClicked((MouseEvent e) -> {
            AgendarPasseiosMain.getStage().close();
            PrincipalMain principal = new PrincipalMain();
            try {
                principal.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(AgendarPasseiosController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        btcancelar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                AgendarPasseiosMain.getStage().close();
                PrincipalMain principal = new PrincipalMain();
                try {
                    principal.start(new Stage());
                } catch (Exception ex) {
                    Logger.getLogger(AgendarPasseiosController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        
        btagendar.setOnMouseClicked((MouseEvent e)->{
           AgendaPasseio(); 
        });
    }

    public void AgendaPasseio() {
        try {
            Passeios p = new Passeios();
            p.setInstituicao(tfinstituicao.getText());
            p.setResponsavel(tfresponsavel.getText());
            p.setFinalidade(btescolha.getText());
            p.setDatavisita(dpdata.getValue());
            PasseiosDAO dao = new PasseiosDAO();

            dao.inserePasseio(p);
            
            Alert agendado = new Alert(AlertType.CONFIRMATION);
            agendado.setHeaderText("Agendado com sucesso!");
            agendado.setContentText("O passeio foi agendado com sucesso!");
            agendado.show();
            tfinstituicao.clear();
            tfresponsavel.clear();
            
                    
            
        } catch (SQLException ex) {
            Logger.getLogger(AgendarPasseiosController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}

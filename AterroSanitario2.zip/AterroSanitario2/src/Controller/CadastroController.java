/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import javafx.event.ActionEvent;
import DAO.UsuarioDAO;
import Main.CadastroMain;
import Main.LoginMain;
import Model.Usuario;
import java.io.File;
import java.net.URL;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import static javafx.scene.effect.BlendMode.RED;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import static javafx.scene.paint.Color.color;
import static javafx.scene.paint.Color.color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Guilherme
 */
public class CadastroController implements Initializable {

    @FXML
    private Label lsh;
    @FXML
    private PasswordField pwsenha;

    @FXML
    private ImageView imgFoto;

    @FXML
    private TextField tfnome;
    @FXML
    private TextField tfemail;
    @FXML
    private TextField tfcnpj;
    @FXML
    private TextField tfins;
    @FXML
    private Button btcad;
    @FXML
    private TextField tfsobrenome;
    @FXML
    private Label le;
    @FXML
    private PasswordField pwcon;
    @FXML
    private Label lcs;
    @FXML
    private Button btcan;
    private String caminhoFoto;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO

        btcad.setOnMouseClicked((MouseEvent e) -> {
            try {
                ValidaCampos();
            } catch (Throwable ex) {
                Logger.getLogger(CadastroController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        btcad.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                try {
                    ValidaCampos();
                } catch (Throwable ex) {
                    Logger.getLogger(CadastroController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        btcan.setOnMouseClicked((MouseEvent e) -> {
            CadastroMain.getStage().close();
        });
        btcan.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                CadastroMain.getStage().close();
            }
        });
        
        imgFoto.setOnMouseClicked((MouseEvent e)->{
        SelecionaFoto();
        });

    }

    public void cadastrar() throws Throwable {
        //pegar todos os dados aqui
        String senha = pwsenha.getText(),
                conf = pwcon.getText(),
                nome = tfnome.getText(),
                sobrenome = tfsobrenome.getText(),
                email = tfemail.getText(),
                cnpj = tfcnpj.getText(),
                instituicao = tfins.getText(),
                usuario = "normal";

        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte messageDigest[] = md.digest(senha.getBytes("UTF-8"));

            StringBuilder sb = new StringBuilder();

            for (byte b : messageDigest) {
                sb.append(String.format("%02X", 0xFF & b));
            }
            String senhaHex = sb.toString();

            if (senha.equals(conf)) {
                UsuarioDAO dao = new UsuarioDAO();
                Usuario u = new Usuario(nome, sobrenome, usuario, instituicao, email, cnpj, senhaHex, caminhoFoto);
                if (dao.insereUsuario(u)) {
                    Alert cadcon = new Alert(Alert.AlertType.CONFIRMATION);
                    CadastroMain.getStage().close();
                    LoginMain login = new LoginMain();
                    login.start(new Stage());
                    cadcon.setHeaderText("Cadastro Realizado com sucesso!!");
                    cadcon.show();

                } else {
                    Alert cadcon = new Alert(AlertType.ERROR);
                    cadcon.setHeaderText("Cadastro nao pode ser realizado");
                    cadcon.show();
                }

            } else {

                Alert errosenha = new Alert(Alert.AlertType.ERROR);
                errosenha.setHeaderText("A confirmação e a senha não são iguais! Tente novamente");
                errosenha.show();
                pwsenha.clear();
                pwcon.clear();
                lsh.setBlendMode(RED);
                lcs.setBlendMode(RED);

            }
        } catch (Exception ee) {
            ee.printStackTrace();
        }
    }

    public void ValidaEmail() {
        String email = tfemail.getText();
        int y = 0;
        UsuarioDAO dao = new UsuarioDAO();
        List<Usuario> usuario = new ArrayList<Usuario>(dao.getList());

        for (int x = 0; x < usuario.size(); x++) {
            if (email.equals(usuario.get(x).getEmail())) {//se email inserido for igual a algum ja cadastrado,erro
                Alert errocad = new Alert(Alert.AlertType.ERROR);//criando o erro
                errocad.setHeaderText("Erro! O email inserido é invalido!");//adcionando corpo ao erro
                errocad.show();//mostrando o erro
                le.setBlendMode(RED);//mudando a cor do campo
                tfemail.clear();//limpando o campo
                y++;

            }
        }
        if (y == 0) {
            try {
                cadastrar();
            } catch (Throwable ex) {
                Logger.getLogger(CadastroController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    public void ValidaCampos() {
        String senha = pwsenha.getText(),
                conf = pwcon.getText(),
                nome = tfnome.getText(),
                sobrenome = tfsobrenome.getText(),
                email = tfemail.getText(),
                cnpj = tfcnpj.getText(),
                instituicao = tfins.getText();

        if (senha == null || senha.trim().isEmpty()
                || conf == null || conf.trim().isEmpty()
                || nome == null || nome.trim().isEmpty()
                || sobrenome == null || sobrenome.trim().isEmpty()
                || email == null || email.trim().isEmpty()
                || cnpj == null || cnpj.trim().isEmpty()
                || instituicao == null || instituicao.trim().isEmpty()) {
            Alert al = new Alert(AlertType.ERROR);
            al.setHeaderText("Campos nao preenchidos");
            al.setContentText("Para prosseguir é necessario que todos os campos estejam preenchidos");
            al.show();
        } else {
            ValidaEmail();
        }

    }

    public void SelecionaFoto() {
        FileChooser f = new FileChooser();
        f.getExtensionFilters().add(new FileChooser.ExtensionFilter("Imagens", "*.jpg", "*.jpeg", "*.png"));
        File file = f.showOpenDialog(new Stage());
        if (file != null) {
            imgFoto.setImage(new Image("file:///" + file.getAbsolutePath()));
            caminhoFoto = file.getAbsolutePath();

        } else {
            Alert al = new Alert(AlertType.WARNING);
            al.setHeaderText("Erro na seleção");
            al.show();
            caminhoFoto = ("/Imagem/imgusers.png");
        }

    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.TransporteDAO;
import DAO.UsuarioDAO;
import Main.CadastroTransporteMain;
import Main.PrincipalMain;
import Main.UsuarioMain;
import Model.Transporte;
import Model.Usuario;
import java.io.File;
import java.net.URL;
import java.security.MessageDigest;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.BlendMode;
import static javafx.scene.effect.BlendMode.RED;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author samuel
 */
public class UsuarioController implements Initializable {

    @FXML
    private Label hjkhj, ln, lbId;

    @FXML
    private TextField tfNomeUs;

    @FXML
    private Label lsn;

    @FXML
    private Label ls;

    @FXML
    private TextField tfSobrenomeUs;

    @FXML
    private Button btSalvar;

    @FXML
    private Label lijh;

    @FXML
    private TextField tfInstUs;

    @FXML
    private TableView<Transporte> tabela;

    @FXML
    private PasswordField pfConfSenhaUs;

    @FXML
    private TextField tfEmailUs;

    @FXML
    private PasswordField pfSenhaUs;

    @FXML
    private Button btAlterar;

    @FXML
    private Label lbPlaca;

    @FXML
    private ImageView imgFoto;

    @FXML
    private Label lbCpf;

    @FXML
    private Label lcs;
    
    @FXML
    private Button btAtualizar;

    @FXML
    private AnchorPane ap2;

    @FXML
    private AnchorPane ap1;

    @FXML
    private Button btExcluir;

    @FXML
    private TableColumn<Transporte, String> clmMotorista;

    @FXML
    private TextField tfCnpjUs;

    @FXML
    private Tab tabUsuario;

    @FXML
    private Tab tabTransporte;

    @FXML
    private TableColumn<Transporte, String> clmPlaca;

    @FXML
    private Button btVoltar;

    @FXML
    private Label lbMotorista;

    @FXML
    private Label lc;

    @FXML
    private Label hjhjhj;

    @FXML
    private Label le;

    @FXML
    private TableColumn<Transporte, Long> clmId;

    @FXML
    private Button btCadastrar;

    @FXML
    private Label li;

    @FXML
    private TabPane tabPane;

    @FXML
    private Button btVoltarTrans;

    private static Usuario user;
    
    private Transporte selecionado;

    private String caminhoFoto = user.getFoto();

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        initUser();
        initTable();
        
        tabela.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                selecionado = (Transporte) newValue;
                mostrarDetalhes();
                
            }
        });

        btSalvar.setOnMouseClicked((MouseEvent e) -> {
            ValidaCampos();
        });

        btSalvar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                ValidaCampos();
            }
        });
        
        imgFoto.setOnMouseClicked((MouseEvent e)->{
            SelecionaFoto();
        });
        
        btCadastrar.setOnMouseClicked((MouseEvent e)->{
        cadastraTrans();
        });
        
        btCadastrar.setOnKeyPressed((KeyEvent evt)->{
            if(evt.getCode()==KeyCode.ENTER){
                cadastraTrans();
            }
        });
        
        btVoltar.setOnMouseClicked((MouseEvent e)->{
        voltar();
        });
        
        btVoltar.setOnKeyPressed((KeyEvent evt)->{
            if(evt.getCode()==KeyCode.ENTER){
            voltar();
            }
        });
        
        btVoltarTrans.setOnKeyPressed((KeyEvent evt)->{
            if(evt.getCode()==KeyCode.ENTER){
            voltar();
            }
        });
        
        btVoltarTrans.setOnMouseClicked((MouseEvent e)->{
        voltar();
        });
        

    }

    public void initUser() {
        
        
        tfNomeUs.setText(getUser().getNome());
        tfSobrenomeUs.setText(getUser().getSobrenome());
        tfInstUs.setText(getUser().getInstituicao());
        tfCnpjUs.setText(getUser().getCnpj());
        tfEmailUs.setText(getUser().getEmail());
        pfSenhaUs.setText(getUser().getSenha());
        pfConfSenhaUs.setText(getUser().getSenha());
        String foto = getUser().getFoto();
        if(foto == null || foto.trim().isEmpty()){
            imgFoto.setImage(new Image("/Imagem/imgusers.png"));
        
    }else{
         imgFoto.setImage(new Image("file:///" + getUser().getFoto()));
            
        }
    }

    public void Atualiza() {
        Long id = getUser().getId();
        String nome = tfNomeUs.getText(), sobrenome = tfSobrenomeUs.getText(), usuario = getUser().getUsuario(), instituicao = tfInstUs.getText(), email = tfEmailUs.getText(),
                cnpj = tfCnpjUs.getText(), senha = pfSenhaUs.getText(), confirma = pfConfSenhaUs.getText();
        try{
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte messageDigest[] = md.digest(senha.getBytes("UTF-8"));

            StringBuilder sb = new StringBuilder();

            for (byte b : messageDigest) {
                sb.append(String.format("%02X", 0xFF & b));
            }
            String senhaHex = sb.toString();
       
        
        if (senha.equals(confirma)) {
            UsuarioDAO dao = new UsuarioDAO();
            Usuario u = new Usuario(id, nome, sobrenome, usuario, instituicao, email, cnpj, senhaHex, caminhoFoto);
            if (dao.alterar(u)) {
                Alert al = new Alert(AlertType.CONFIRMATION);
                al.setHeaderText("Usuario atualizado com sucesso");
                al.show();

            } else {
                Alert al = new Alert(AlertType.ERROR);
                al.setHeaderText("Não foi possivel realizar as modificações");
                al.setContentText("Tente novamente mais tarde!");
                al.show();

            }

        } else {
            Alert al = new Alert(AlertType.ERROR);
            al.setHeaderText("Erro a senha e a confirmação não são iguais");
            al.setContentText("Para prosseguir é necessario que elas sejam iguais");
            lsn.setBlendMode(BlendMode.RED);
            lcs.setBlendMode(BlendMode.RED);
            pfSenhaUs.clear();
            pfConfSenhaUs.clear();
            al.showAndWait();

        }
        }catch(Exception ee) {
            ee.printStackTrace();
        }
    }

    public void ValidaEmail() {
        String email = tfEmailUs.getText();
        int y = 0;
        UsuarioDAO dao = new UsuarioDAO();
        List<Usuario> usuario = new ArrayList<Usuario>(dao.getList());

        for (int x = 0; x < usuario.size(); x++) {
            if(email.equals(user.getEmail())){ // se o email inserido for igual ao que o usuario cadastrou entao
            // ele nao faz nada e continua para o passo seguinte
            } else if (email.equals(usuario.get(x).getEmail())) {//se email inserido for igual a algum ja cadastrado,erro
                Alert errocad = new Alert(Alert.AlertType.ERROR);//criando o erro
                errocad.setHeaderText("Erro! O email inserido é invalido!");//adcionando corpo ao erro
                errocad.show();//mostrando o erro
                le.setBlendMode(RED);//mudando a cor do campo
                tfEmailUs.clear();//limpando o campo
                y++; // y recebe +1, isso significa que o email inserido é igual a algum email do bd

            }

        }
        if (y == 0) { // se y é igual a zero significa que o email inserido nao é igual a  nenhum email presente no bd
            try { // dessa forma o usuario consegue cadastrar...
                Atualiza();
            } catch (Throwable ex) {
                Logger.getLogger(CadastroController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void ValidaCampos() {
        String senha = pfSenhaUs.getText(),
                conf = pfConfSenhaUs.getText(),
                nome = tfNomeUs.getText(),
                sobrenome = tfSobrenomeUs.getText(),
                email = tfEmailUs.getText(),
                cnpj = tfCnpjUs.getText(),
                instituicao = tfInstUs.getText();

        if (senha == null || senha.trim().isEmpty()
                || conf == null || conf.trim().isEmpty()
                || nome == null || nome.trim().isEmpty()
                || sobrenome == null || sobrenome.trim().isEmpty()
                || email == null || email.trim().isEmpty()
                || cnpj == null || cnpj.trim().isEmpty()
                || instituicao == null || instituicao.trim().isEmpty()) {
            Alert al = new Alert(AlertType.ERROR);
            al.setHeaderText("Campos nao preenchidos");
            al.setContentText("Para prosseguir é necessario que todos os campos estejam preenchidos");
            al.show();
        } else {
            ValidaEmail();
        }

    }

    public void initTable() {
        TransporteDAO dao = new TransporteDAO();
        List<Transporte> transporte = new ArrayList<Transporte>(dao.getList());
                for(int x =0; x<transporte.size(); x++){
                    
                if(transporte.get(x).getId_usuario().equals(user.getId())){
                clmId.setCellValueFactory(new PropertyValueFactory("id"));
                clmMotorista.setCellValueFactory(new PropertyValueFactory("motorista"));
                clmPlaca.setCellValueFactory(new PropertyValueFactory("placa"));
                tabela.setItems(atualizaTabela());
                }
            }
    }
      
    

    public ObservableList<Transporte> atualizaTabela() {
        TransporteDAO dao = new TransporteDAO();
            return FXCollections.observableArrayList(dao.getList());

    }
    
    public void mostrarDetalhes(){
        if(selecionado != null){
            lbId.setText(selecionado.getId().toString());
            lbMotorista.setText(selecionado.getMotorista());
            lbPlaca.setText(selecionado.getPlaca());
            lbCpf.setText(selecionado.getCpf());
        }else{
            lbId.setText("");
            lbMotorista.setText("");
            lbPlaca.setText("");
            lbCpf.setText("");
        }
    
    }

    public static Usuario getUser() {
        return user;
    }

    public static void setUser(Usuario aUser) {
        user = aUser;
    }

    public void voltar(){
         Long id = getUser().getId();
        String nome = tfNomeUs.getText(), sobrenome = tfSobrenomeUs.getText(), usuario = getUser().getUsuario(), instituicao = tfInstUs.getText(), email = tfEmailUs.getText(),
                cnpj = tfCnpjUs.getText(), senha = pfSenhaUs.getText(), confirma = pfConfSenhaUs.getText();
    Usuario u = new Usuario(id, nome, sobrenome, usuario, instituicao, email, cnpj, senha, caminhoFoto);
    PrincipalMain p = new PrincipalMain(u);
        try {
            UsuarioMain.getStage().close();
            p.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(UsuarioController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public void SelecionaFoto(){
        FileChooser f = new FileChooser();
        f.getExtensionFilters().add(new FileChooser.ExtensionFilter("Imagens", "*.jpg", "*.jpeg", "*.png"));
        File file = f.showOpenDialog(new Stage());
        if (file != null) {
            imgFoto.setImage(new Image("file:///" + file.getAbsolutePath()));
            caminhoFoto = file.getAbsolutePath();

        } else {
            Alert al = new Alert(AlertType.WARNING);
            al.setHeaderText("Erro na seleção");
            al.show();
            caminhoFoto = ("/Imagem/imgusers.png");
        }

    }
    
    public void DeletaTrans(){
        if(selecionado != null ){
        TransporteDAO dao = new TransporteDAO();
        dao.delete(selecionado);
        
            Alert al = new Alert(AlertType.CONFIRMATION);
            al.setHeaderText("Sucesso!");
            al.setContentText("Transporte deletado com sucesso!");
            al.show();

            }else {
            Alert al = new Alert(AlertType.WARNING);
            al.setHeaderText("Nenhum transporte selecionado!");
            al.setContentText("Para executar a ação é necessario selecionar um transporte!");
            al.show();
       }
        
    }
  
    public void cadastraTrans(){
           
        CadastroTransporteMain c = new CadastroTransporteMain(user); 
        
        try {
            c.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(UsuarioController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    public void AlteraTrans(){
    if(selecionado != null){
        
    }
        
    
    }
    
 }


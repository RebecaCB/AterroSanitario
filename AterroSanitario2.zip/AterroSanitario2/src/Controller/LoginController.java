/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.UsuarioDAO;
import Main.CadastroMain;
import Main.LoginMain;
import Main.PrincipalMain;
import Model.Usuario;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 *
 * @author Aluno
 */
public class LoginController implements Initializable {

    @FXML
    private PasswordField pwsenha;
    @FXML
    private Label senha;
    @FXML
    private Label lsbv;
    @FXML
    private Button btsair;
    @FXML
    private Button btcadastro;
    @FXML
    private TextField txlogin;
    @FXML
    private Label login;
    @FXML
    private Button btentrar;
    @FXML
    private AnchorPane ap;

    @FXML
    private void handleButtonAction(ActionEvent event) {

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        pwsenha.setOnKeyPressed((KeyEvent evt)->{
            if(evt.getCode()== KeyCode.ENTER){
                Logar();
            }
        });
        
        txlogin.setOnKeyPressed((KeyEvent evt)->{
            if(evt.getCode()==KeyCode.ENTER){
                Logar();
            }
        });
        
        btcadastro.setOnMouseClicked((MouseEvent evt) -> {
            CadUser();
        });
        btcadastro.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                CadUser();
            }
        });

        btsair.setOnMouseClicked((MouseEvent e) -> {
            LoginMain.getStage().close();
        });
        btsair.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                LoginMain.getStage().close();
            }
        });

        btentrar.setOnMouseClicked((MouseEvent e) -> {
           
                Logar();

        });
        btentrar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                try {
                    Logar();
                } catch (Throwable ex) {
                    Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

    }

    public void Logar() { //loga os usuarios que são cadastrados no BD
        String username;
        String senha = pwsenha.getText();
        try {

            UsuarioDAO dao = new UsuarioDAO();
            List<Usuario> usuario = new ArrayList<Usuario>((dao.getList()));

            for (int x = 0; x < usuario.size(); x++) {
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                byte messageDigest[] = md.digest(senha.getBytes("UTF-8"));

                StringBuilder sb = new StringBuilder();

                for (byte b : messageDigest) {
                    sb.append(String.format("%02X", 0xFF & b));
                }
                String senhaHex = sb.toString();

                if (txlogin.getText().equals(usuario.get(x).getEmail()) && usuario.get(x).getSenha().equals(senhaHex)) {
 

                    username = (usuario.get(x).getNome() + " " + usuario.get(x).getSobrenome());
                    Long id = usuario.get(x).getId();
                    String nome = usuario.get(x).getNome(),
                            sobrenome = usuario.get(x).getSobrenome(),
                            user = usuario.get(x).getUsuario(),
                            instituicao = usuario.get(x).getInstituicao(),
                            email = usuario.get(x).getEmail(),
                            cnpj = usuario.get(x).getCnpj(),
                            foto = usuario.get(x).getFoto();
                    
                    Usuario selecionado = new Usuario(id, nome, sobrenome, user, instituicao, email, cnpj, senha,foto);
                
                    PrincipalMain principal = new PrincipalMain(selecionado);
                   
                    
                    try {
                        LoginMain.getStage().close();
                        principal.start(new Stage());
                        Alert login = new Alert(Alert.AlertType.CONFIRMATION);
                        login.setHeaderText("Seja bem vindo(a) " + username);
                        login.show();
                        x = usuario.size();
                    } catch (Exception ex) {
                        Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } else if (x == usuario.size() - 1) {
                    Alert erro = new Alert(Alert.AlertType.ERROR);
                    erro.setHeaderText("Usuario e/ou senha invalidos! "
                            + "Tente novamente");
                    erro.show();
                    pwsenha.clear();
                    txlogin.clear();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void CadUser() {
        CadastroMain CadastroMain = new CadastroMain();
        LoginMain.getStage().close();
        try {
            CadastroMain.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}

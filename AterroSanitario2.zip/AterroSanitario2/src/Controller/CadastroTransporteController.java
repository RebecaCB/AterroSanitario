/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.TransporteDAO;
import Main.CadastroTransporteMain;
import Main.PrincipalMain;
import Model.Transporte;
import Model.Usuario;
import Model.ValidaCPF;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Aluno
 */
public class CadastroTransporteController implements Initializable {
    
    @FXML
    private TextField tfCpf;

    @FXML
    private TextField txEmpresa;

    @FXML
    private TextField tfMotorista;

    @FXML
    private TextField tfPlaca;

    @FXML
    private Button btRealizaCad;
    

    private static Usuario user;

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        initEmp();

        btRealizaCad.setOnMouseClicked((MouseEvent e) -> {
           ValidaTransporte();

        });
        btRealizaCad.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                ValidaTransporte();
            }
        });

    }

    public void ValidaTransporte() {
        int y = 0;
        TransporteDAO dao = new TransporteDAO();
        try {
            List<Transporte> transportes = new ArrayList<Transporte>(dao.getList());

            for (int x = 0; x < transportes.size(); x++) {
                if (tfCpf.getText().equals(transportes.get(x).getCpf())) {
                    Alert errocpf = new Alert(Alert.AlertType.ERROR);
                    errocpf.setHeaderText("O cpf inserido é invalido! Tente novamente");
                    errocpf.show();
                    tfCpf.clear();
                    y++;
                }
            }
            if (y == 0) {
              ValidaCpf();

            }
        } catch (Exception ex) {
            Logger.getLogger(CadastroTransporteController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void CadastraTransporte() {
        String motorista = tfMotorista.getText(),
                Cpf = tfCpf.getText(),
                placa = tfPlaca.getText(),
                empresa = txEmpresa.getText();
        Long id_usuario = (user.getId());

        TransporteDAO dao = new TransporteDAO();
        Transporte b = new Transporte(motorista, Cpf, placa, empresa, id_usuario);

        if (dao.insereTransporte(b)) {

            Alert CadRealizado = new Alert(AlertType.CONFIRMATION);
            CadRealizado.setHeaderText("Cadastro realizado com sucesso!!");
            CadRealizado.show();
        } else {
            Alert CadError = new Alert(AlertType.ERROR);
            CadError.setHeaderText("Erro ao cadastrar transporte");
            CadError.setContentText("Não foi possivel cadastrar Tente novamente");
        }

    }

    public static Usuario getUser() {
        return user;
    }

    public static void setUser(Usuario aUser) {
        user = aUser;
    }

    public void initEmp() {
        txEmpresa.setText(user.getInstituicao());

    }
    
    public void ValidaCpf(){
    String Cpf = tfCpf.getText();
    
    if(ValidaCPF.isCPF(Cpf)==true){
         
        CadastraTransporte();
        
    }else{
        Alert al = new Alert(AlertType.ERROR);
        al.setHeaderText("CPF inserido invalido");
        al.setContentText("Para prosseguir é necessairo inserir um cpf valido");
        al.show();
        }
    }
}

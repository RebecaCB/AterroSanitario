/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Main.AgendaEntregasMain;
import Main.AgendarEntregasMain;
import Main.AgendarPasseiosMain;
import Main.CadastroTransporteMain;
import Main.LoginMain;
import Main.PrincipalMain;
import Main.UsuarioMain;
import Model.Usuario;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Aluno
 */
public class PrincipalController implements Initializable {


    @FXML private Label lbn;
    
    @FXML private Label lbsn;
    
    @FXML private Label lbins;
    
    @FXML  private Button btadp;

    @FXML  private Button btlogout;

    @FXML  private Button btusuario;

    @FXML  private Button btae;

    @FXML  private Button btade;

    @FXML  private Button btct;

    @FXML   private ImageView imgFoto;
    
    @FXML  private Button btap;
    
    private static Usuario user;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        InformacoesUser();
            
        btct.setOnMouseClicked((MouseEvent e)->{
          CadastrarTransporte();
        });
        btct.setOnKeyPressed((KeyEvent evt)->{
          if(evt.getCode()==KeyCode.ENTER){
              CadastrarTransporte();
          }  
        });
       
        
        btae.setOnMouseClicked((MouseEvent e)->{
           AgendarEntregas();
        });
        btae.setOnKeyPressed((KeyEvent evt)->{
           if(evt.getCode()==KeyCode.ENTER){
              AgendarEntregas();
           }
        });
       
        
        btap.setOnMouseClicked((MouseEvent e)->{
           AgendarPasseios();
        });
        btap.setOnKeyPressed((KeyEvent evt)->{
            if(evt.getCode()==KeyCode.ENTER){
                AgendarPasseios();
            }
        });
        
        
        btlogout.setOnMouseClicked((MouseEvent e)->{
            logout();
        });
        btlogout.setOnKeyPressed((KeyEvent evt)->{
            if(evt.getCode()==KeyCode.ENTER){
               logout();
            }
        });
       
        
        btade.setOnMouseClicked((MouseEvent e)->{
            AgendadeEntregas();
        });
        btade.setOnKeyPressed((KeyEvent evt)->{
           AgendadeEntregas();
        });
       
        
        btusuario.setOnMouseClicked((MouseEvent e)->{
          usuario();
        });
        btusuario.setOnKeyPressed((KeyEvent evt)->{
           if(evt.getCode()==KeyCode.ENTER){
              usuario();
           } 
        });
    }    
    public void usuario(){
             UsuarioMain u = new UsuarioMain(user);
               
               try {
                   PrincipalMain.getStage().close();
                   u.start(new Stage());
               } catch (Exception ex) {
                   Logger.getLogger(PrincipalController.class.getName()).log(Level.SEVERE, null, ex);
               }
    }
    public void AgendadeEntregas(){
            AgendaEntregasMain aem = new AgendaEntregasMain();
           PrincipalMain.getStage().close();
            try {
                aem.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(PrincipalController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    public void AgendarEntregas(){
                 AgendarEntregasMain ae = new AgendarEntregasMain();
               PrincipalMain.getStage().close();
               try {
                   ae.start(new Stage());
               } catch (Exception ex) {
                   Logger.getLogger(PrincipalController.class.getName()).log(Level.SEVERE, null, ex);
               }
    }
    public void AgendadePasseios(){
        
    }
    public void AgendarPasseios(){
                 AgendarPasseiosMain ap = new AgendarPasseiosMain();
                PrincipalMain.getStage().close();
                try {
                    ap.start(new Stage());
                } catch (Exception ex) {
                    Logger.getLogger(PrincipalController.class.getName()).log(Level.SEVERE, null, ex);
                }
    }
    public void CadastrarTransporte(){
         CadastroTransporteMain ct = new CadastroTransporteMain();
              PrincipalMain.getStage().close();
              try {
                  ct.start(new Stage());
              } catch (Exception ex) {
                  Logger.getLogger(PrincipalController.class.getName()).log(Level.SEVERE, null, ex);
              }
    }
    public void logout(){
                LoginMain login = new LoginMain();
                PrincipalMain.getStage().close();
                try {
                    login.start(new Stage());
                } catch (Exception ex) {
                    Logger.getLogger(PrincipalController.class.getName()).log(Level.SEVERE, null, ex);
                }
    }
    
    public static Usuario getUser() {
        return user;
    }

    public static void setUser(Usuario aUser) {
        user = aUser;
    }
    
    
    public void InformacoesUser(){
        lbn.setText(getUser().getNome());
        lbsn.setText(getUser().getSobrenome());
        lbins.setText(getUser().getInstituicao());
        String foto = getUser().getFoto();
        if(foto == null || foto.trim().isEmpty()){
            imgFoto.setImage(new Image("/Imagem/imgusers.png"));
        }else{
        imgFoto.setImage(new Image("file:///" + getUser().getFoto()));
        }
    }
}

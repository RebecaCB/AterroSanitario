/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Main.InterfaceMain;
import Main.LoginMain;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Aluno
 */
public class InterfaceController implements Initializable {
    @FXML private Button btEntrar;
    @FXML private Button btSair;
    @FXML private AnchorPane ap;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btEntrar.setOnMouseClicked(( MouseEvent e) -> {
            LoginMain LoginMain = new LoginMain();
            InterfaceMain.getStage().close();
            try{
                LoginMain.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(InterfaceController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        btEntrar.setOnKeyPressed((KeyEvent evt)->{
           if(evt.getCode()==KeyCode.ENTER){
               LoginMain LoginMain = new LoginMain();
               InterfaceMain.getStage().close();
               try{
                  LoginMain.start(new Stage());
               } catch (Exception ex) {
                   Logger.getLogger(InterfaceController.class.getName()).log(Level.SEVERE, null, ex);
               }
           } 
        });
        btSair.setOnMouseClicked((MouseEvent e)->{
            InterfaceMain.getStage().close();
        });
        btSair.setOnKeyPressed((KeyEvent evt)->{
           if(evt.getCode()==KeyCode.ENTER){
               InterfaceMain.getStage().close();
           } 
        });
    }    
}

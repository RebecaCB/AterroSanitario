/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import JDBC.ConnectionFactory;
import Model.Passeios;
import Model.Transporte;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author samuel
 */
public class PasseiosDAO {
    private Connection conexao;
   
    public PasseiosDAO(){
    this.conexao = new ConnectionFactory().getConnection();
}
    public void inserePasseio(Passeios p) throws SQLException{
    try{
        String sql = "INSERT INTO passeios( instituicao, responsavel, finalidade, data) VALUES(?,?,?,?)";
        
        Date data = Date.valueOf(p.getDatavisita());
        
        PreparedStatement stmt = conexao.prepareStatement(sql);
        stmt.setString(1, p.getInstituicao());
        stmt.setString(2,p.getResponsavel());
        stmt.setString(3, p.getFinalidade());
        stmt.setDate(4, Date.valueOf(p.getDatavisita()));
        stmt.execute();
        stmt.close();
        conexao.close();
        }catch(SQLException ex){
            Logger.getLogger(TransporteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public List<Transporte> getList() throws SQLException{
        List<Transporte> transportes = new ArrayList<Transporte>();
        try{
            
        
        String sql = "SELECT * FROM transporte";
        PreparedStatement stmt = conexao.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        while(rs.next()){
            Transporte t = new Transporte();
            t.setMotorista(rs.getString("motorista"));
            t.setCpf(rs.getString("cpf"));
            t.setPlaca(rs.getString("placa"));
            t.setEmpresa(rs.getString("empresa"));
            transportes.add(t);
        }
        rs.close();
        stmt.close();
        
        }  catch(SQLException ex){
            ex.printStackTrace();
        } 
        return transportes;
    }
    public void alterar(Transporte t) throws SQLException{
        String sql = "UPDATE transporte SET motorista=?, cpf=?, placa=?, empresa=?";
        try{
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1,t.getMotorista());
            stmt.setString(2, t.getCpf());
            stmt.setString(3, t.getPlaca());
            stmt.setString(4,t.getEmpresa());
            stmt.execute();
            conexao.close();
        }catch(SQLException ex){
           throw new RuntimeException();
        }
    }
}

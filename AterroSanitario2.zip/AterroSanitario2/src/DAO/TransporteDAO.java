/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import JDBC.ConnectionFactory;
import Model.Transporte;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author samuel
 */
public class TransporteDAO {

    private Connection conexao;

    public TransporteDAO() {
        this.conexao = new ConnectionFactory().getConnection();
    }

    public boolean insereTransporte(Transporte t){
        try {
            String sql = "INSERT INTO transporte( motorista, cpf, placa, empresa, id_usuario) VALUES(?,?,?,?,?)";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, t.getMotorista());
            stmt.setString(2, t.getCpf());
            stmt.setString(3, t.getPlaca());
            stmt.setString(4, t.getEmpresa());
            stmt.setLong(5, t.getId_usuario());
            stmt.execute();
            stmt.close();
            conexao.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(TransporteDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public List<Transporte> getList() {
        List<Transporte> transportes = new ArrayList<Transporte>();
        try {

            String sql = "SELECT * FROM transporte";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Transporte t = new Transporte();
                t.setId(rs.getLong("id"));
                t.setMotorista(rs.getString("motorista"));
                t.setCpf(rs.getString("cpf"));
                t.setPlaca(rs.getString("placa"));
                t.setEmpresa(rs.getString("empresa"));
                t.setId_usuario(rs.getLong("id_usuario"));
                transportes.add(t);
            }
            rs.close();
            stmt.close();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return transportes;
    }

    public boolean alterar(Transporte t) {
        String sql = "UPDATE transporte SET motorista=?, cpf=?, placa=?, empresa=?";
        try {
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, t.getMotorista());
            stmt.setString(2, t.getCpf());
            stmt.setString(3, t.getPlaca());
            stmt.setString(4, t.getEmpresa());
            stmt.execute();
            conexao.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public boolean delete(Transporte t) {
        String sql = "DELETE FROM transporte WHERE id =?;";
        PreparedStatement stmt;
        try {
            stmt = conexao.prepareStatement(sql);
            stmt.setLong(1, t.getId());
            stmt.execute();
            stmt.close();
            conexao.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(TransporteDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public List<Transporte> getListSelecionados() {
        List<Transporte> transportes = new ArrayList<Transporte>();
        try {
            String sql = "SELECT * FROM transporte INNER JOIN usuario ON transporte.id_usuario = usuario.id";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Transporte t = new Transporte();
                t.setId(rs.getLong("id"));
                t.setMotorista(rs.getString("motorista"));
                t.setCpf(rs.getString("cpf"));
                t.setPlaca(rs.getString("placa"));
                t.setEmpresa(rs.getString("empresa"));
                t.setId_usuario(rs.getLong("id_usuario"));
                transportes.add(t);
            }
            rs.close();
            stmt.close();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return transportes;
    }

}

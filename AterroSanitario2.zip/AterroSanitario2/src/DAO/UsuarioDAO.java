
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import JDBC.ConnectionFactory;
import Model.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Aluno
 */
public class UsuarioDAO {
    
        private Connection conexao;
          
        public UsuarioDAO(){
            this.conexao = new ConnectionFactory().getConnection();
        }
            public boolean insereUsuario(Usuario user){
           try{
               String sql = "INSERT INTO usuario(nome,sobrenome,usuario, email,instituicao, cnpj, senha, foto ) VALUES (?,?,?,?,?,?,?,?)";
                PreparedStatement stmt = conexao.prepareStatement(sql);
                stmt.setString(1, user.getNome());
                stmt.setString(2, user.getSobrenome());
                stmt.setString(3, user.getUsuario());
                stmt.setString(4, user.getEmail());
                stmt.setString(5, user.getInstituicao());
                stmt.setString(6, user.getCnpj());
                stmt.setString(7, user.getSenha());
                stmt.setString(8, user.getFoto());
                stmt.execute();
                stmt.close();
                 conexao.close();
                 return true;
                      } catch (SQLException ex) {
                      Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
                      return false;
             }
       }

            public List<Usuario> getList(){
                List<Usuario> usuarios = new ArrayList<Usuario>();
                try{
                    String sql="SELECT * FROM usuario"; 
                    PreparedStatement stmt = conexao.prepareStatement(sql);
                    ResultSet rs = stmt.executeQuery();
                    while(rs.next()){
                        Usuario u = new Usuario();
                        u.setId(rs.getLong("id"));
                        u.setNome(rs.getString("nome"));
                        u.setSobrenome(rs.getString("sobrenome"));
                        u.setUsuario(rs.getString("usuario"));
                        u.setEmail(rs.getString("email"));
                        u.setInstituicao(rs.getString("instituicao"));
                        u.setCnpj(rs.getString("cnpj"));
                        u.setSenha(rs.getString("senha"));
                        u.setFoto(rs.getString("foto"));
                        usuarios.add(u);
                    }
                    rs.close();
                    stmt.close();
                   
                        }catch(SQLException e){
                            e.printStackTrace(); 
                    }
               return usuarios; 
           }
                       
     
  
             public boolean alterar(Usuario user){
                String sql= "UPDATE usuario SET nome=?, sobrenome = ?, usuario = ?, email= ?, instituicao =?, cnpj = ?, senha = ?, foto = ?;";
                try{
                    PreparedStatement stmt = conexao.prepareStatement(sql);
                    stmt.setString(1,user.getNome());
                    stmt.setString(2,user.getSobrenome());
                    stmt.setString(3,user.getUsuario());
                    stmt.setString(4,user.getEmail());
                    stmt.setString(5,user.getInstituicao());
                    stmt.setString(6,user.getCnpj());
                    stmt.setString(7,user.getSenha());
                    stmt.setString(8, user.getFoto());
                    stmt.execute();
                    stmt.close();
                    conexao.close();
                    return true;
                }catch(SQLException ex) {
                    Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
                   return false;
             }

        }
             public boolean delete(Usuario u){
                 String sql = "DELETE FROM usuario WHERE id = ?;";
                 
            try {
                PreparedStatement stmt = conexao.prepareStatement(sql);
                stmt.setLong(1, u.getId());
                stmt.execute();
                stmt.close();
                conexao.close();
                return true;
                
                
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
                return false;
            }
                 
             }

}
    

